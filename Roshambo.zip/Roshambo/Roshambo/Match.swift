//
//  Match.swift
//  Roshambo
//
//  Created by Thong, Mikey on 7/12/16.
//  Copyright © 2016 Thong, Mikey. All rights reserved.
//

import Foundation

struct Match {
    let playerMove: Game
    let opponentMove: Game
    let matchDate: NSDate
    
    init(player: Game, opponent: Game) {
        self.playerMove = player
        self.opponentMove = opponent
        self.matchDate = NSDate()
    }
    
    var win: Game {
        get {
            return playerMove.playerWin(opponentMove) ? playerMove : opponentMove
        }
    }
    
    var lose: Game {
        get {
            return playerMove.playerWin(opponentMove) ? opponentMove : playerMove
        }
    }
}