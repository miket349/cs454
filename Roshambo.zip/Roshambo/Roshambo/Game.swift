//
//  Game.swift
//  Roshambo
//
//  Created by Thong, Mikey on 7/12/16.
//  Copyright © 2016 Thong, Mikey. All rights reserved.
//

import Foundation

enum Game {
    case Rock, Paper, Scissors
    
    init() {
        switch arc4random() % 3 {
        case 0:
            self = .Rock
        case 1:
            self = .Paper
        default:
            self = .Scissors
        }
    }
    
    func playerWin(opponent: Game) -> Bool {
        switch(self, opponent) {
        case (.Rock, .Scissors), (.Paper, .Rock), (.Scissors, .Paper):
            return false
        default:
            return true
        }
    }
}

/*extension Game: CustomStringConvertible {
    var choiceDescription: String {
        get {
            switch(self) {
            case .Rock:
                return "Rock"
            case .Paper:
                return "Paper"
            case .Scissors:
                return "Scissors"
            }
        }
    }
}*/