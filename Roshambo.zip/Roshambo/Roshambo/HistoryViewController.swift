//
//  HistoryViewController.swift
//  Roshambo
//
//  Created by Thong, Mikey on 7/12/16.
//  Copyright © 2016 Thong, Mikey. All rights reserved.
//

import UIKit
import Foundation

class HistoryViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var history = [Match]()
    
    @IBOutlet weak var tableView: UITableView!
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return history.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("HistoryCell")! as UITableViewCell
        let matchGame = self.history[indexPath.row]
        cell.textLabel!.text = gameStatus(matchGame)
        cell.detailTextLabel!.text = "\(matchGame.playerMove) vs. \(matchGame.opponentMove)"
        return cell
    }
    
    func gameStatus(match: Match) -> String {
        if (match.playerMove == match.opponentMove) {
            return "Tie"
        } else if (match.playerMove.playerWin(match.opponentMove)) {
            return "Win!"
        } else {
            return "Lose."
        }
    }
    
    @IBAction func dimissHistory(sender: AnyObject) {
        self.dismissViewControllerAnimated(true, completion: nil)
    }
}
