//
//  ViewController.swift
//  Roshambo
//
//  Created by Thong, Mikey on 6/29/16.
//  Copyright © 2016 Thong, Mikey. All rights reserved.
//

import UIKit

class PlayViewController: UIViewController {

    var history = [Match]()
    
    @IBAction func playRock(sender: UIButton) {
        makeHistory(Game.Rock)
        let controller = self.storyboard?.instantiateViewControllerWithIdentifier("ResultViewController") as! ResultViewController
        controller.userChoice = getUserChoice(sender)
        presentViewController(controller, animated: true, completion: nil)
    }
    
    @IBAction func playPaper(sender: UIButton) {
        makeHistory(Game.Paper)
        performSegueWithIdentifier("playIt", sender: sender)
    }
    
    @IBAction func playScissors(sender: UIButton) {
        makeHistory(Game.Scissors)
    }
    
    @IBAction func viewHistory(sender: UIButton) {
        let controller = self.storyboard?.instantiateViewControllerWithIdentifier("HistoryViewController") as! HistoryViewController
        controller.history = self.history
        presentViewController(controller, animated: true, completion: nil)
    }
    
    func makeHistory(player: Game) {
        let opponent = Game()
        let matchGame = Match(player: player, opponent: opponent)
        history.append(matchGame)
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "playIt" {
            let controller = segue.destinationViewController as! ResultViewController
            controller.userChoice = getUserChoice(sender as! UIButton)
        }
    }
    
    private func getUserChoice(sender: UIButton) -> Choice {
        let choice = sender.titleForState(.Normal)!
        return Choice(rawValue: choice)!
    }
}

