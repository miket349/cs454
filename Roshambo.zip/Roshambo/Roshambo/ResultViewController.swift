//
//  ResultViewController.swift
//  Roshambo
//
//  Created by Thong, Mikey on 6/29/16.
//  Copyright © 2016 Thong, Mikey. All rights reserved.
//

import UIKit

enum Choice: String {
    case Rock = "Rock"
    case Paper = "Paper"
    case Scissors = "Scissors"
    
    static func getOpponentChoice() -> Choice {
        let choice = ["Rock", "Paper", "Scissors"]
        let randomChoice = Int(arc4random_uniform(3))
        return Choice(rawValue: choice[randomChoice])!
    }
    
    func playerWin(player: Choice, opponent: Choice) -> Bool {
        switch(player, opponent) {
        case (.Rock, .Scissors), (.Paper, .Rock), (.Scissors, .Paper):
            return false
        default:
            return true
        }
    }
}

class ResultViewController: UIViewController {
    @IBOutlet private weak var labelResult: UILabel!
    @IBOutlet private weak var imageResult: UIImageView!
    
    var userChoice: Choice!
    private let opponentChoice: Choice = Choice.getOpponentChoice()
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        result()
    }
    
    private func result() {
        var imageName: String
        var labelText: String
        
        //let imagePicName = "\(userChoice.rawValue)-\(opponentChoice.rawValue)"
        let matchName = "\(userChoice.rawValue) vs. \(opponentChoice.rawValue)"
        
        switch(userChoice!, opponentChoice) {
        case let (user, opponent) where user == opponent:
            imageName = "tie"
            labelText = "\(matchName)Tie"
        case (.Rock, .Scissors), (.Paper, .Rock), (.Scissors, .Paper):
            imageName = "\(userChoice.rawValue)-\(opponentChoice.rawValue)"
            labelText = "\(matchName)\nWin!"
        default:
            imageName = "\(opponentChoice.rawValue)-\(userChoice.rawValue)"
            labelText = "\(matchName)\nLose..."
        }
        
        imageName = imageName.lowercaseString
        labelResult.text = labelText
        imageResult.image = UIImage(named: imageName)
    }
    
    @IBAction private func playAgain() {
        dismissViewControllerAnimated(true, completion: nil)
    }

}